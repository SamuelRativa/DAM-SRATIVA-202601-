import React from "react";

import {
    AuthTemplate,
} from "../../Components/Templates";

import {
    RegisterForm,
} from "../../Components/Organims";

const RegisterPage = () => {

    const handleRegister = () => {
        console.log("Register");
    };

    return (
        <AuthTemplate>

            <RegisterForm
                onSubmit={handleRegister}
            />

        </AuthTemplate>
    );
};

export default RegisterPage;