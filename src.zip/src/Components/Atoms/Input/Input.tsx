import React from "react";
import {
    TextInput,
    StyleSheet,
} from "react-native";

interface InputProps {
    placeholder: string;
    secureTextEntry?: boolean;
}

const Input = ({
    placeholder,
    secureTextEntry = false,
}: InputProps) => {
    return (
        <TextInput
            placeholder={placeholder}
            secureTextEntry={secureTextEntry}
            style={styles.input}
            placeholderTextColor="#999"
        />
    );
};

const styles = StyleSheet.create({
    input: {
        width: "100%",
        height: 50,
        borderWidth: 1,
        borderColor: "#ccc",
        borderRadius: 10,
        paddingHorizontal: 15,
        marginBottom: 15,
        fontSize: 16,
    },
});

export default Input;